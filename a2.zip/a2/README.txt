Student 1: Alexander Ingham, 20054078, 16adwi@queensu.ca
Student 2: Adam Farley, 20053344, adam.farley@queensu.ca (16ajbf)