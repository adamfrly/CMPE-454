// fg_stroke.h
//
// from freeglut


extern SFG_StrokeFont fgStrokeMonoRoman;
